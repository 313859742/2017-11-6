const b = require('./b');

console.log(b);
