export const a =  (name)=> {
    return {name: name}
}
export const b =  (name)=> {
    return {name: name}
}
export const c =  (name)=> {
    return {name: name}
}

console.log(90);
