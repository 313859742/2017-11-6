// 接收的是 module.exports
module.exports =9;

// exports 和 module.exports 引用的地址相等
exports = module.exports; //地址引用

// 123: {}
// module.exports -> 123
// exports-> 123
// exports.a=1
// exports.b=2

// 345: {a:1}
exports = 8
