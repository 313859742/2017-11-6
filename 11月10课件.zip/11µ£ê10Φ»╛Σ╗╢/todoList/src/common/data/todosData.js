
// 1, 2, 3, 4, 5
// 7, 1, 2, 3, 4, 6

export default [
    {
        id: Math.random(),
        content: '奋上',
        isActive: true
    },
    {
        id: Math.random(),
        content: '发多少',
        isActive: true
    },
    {
        id: Math.random(),
        content: 'fds',
        isActive: true
    },
    {
        id: Math.random(),
        content: '发多少愧疚和',
        isActive: true
    },
    {
        id: Math.random(),
        content: '饭店烧烤',
        isActive: true
    },

]
