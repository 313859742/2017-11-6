<template>
  <div>
    我是VIP用户
  </div>
</template>
<script>
  export default {
    mounted () {
      console.log(this.$route)
    }
  }
</script>
