<template>
  <div>
    我是普通用户
  </div>
</template>
