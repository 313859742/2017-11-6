<template>
  <div>
    我是user页面

    <hr>

    <router-view />

  </div>
</template>
