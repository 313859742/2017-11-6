<template>
  <div>
    我是付费用户
  </div>
</template>
