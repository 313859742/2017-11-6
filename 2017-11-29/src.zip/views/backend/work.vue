<template>
  <div>
    <div class="block-content">
      这是工作台页面
    </div>
  </div>
</template>
